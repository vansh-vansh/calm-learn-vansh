import { NextResponse } from "next/server";

export async function GET() {
  const playlists = [
    { id: "PLxyGaR3hEy3gvV4VbbP8pza7MtoJkGu6M", title:"Physics" }
  ];
  return NextResponse.json({playlists});
}