export default function RootLayout({ children }) {
  return (
    <html>
      <body style={{background:'#000',color:'#0ff',margin:0}}>
        {children}
      </body>
    </html>
  );
}