import Sidebar from "../components/Sidebar";
import VideoPlayer from "../components/VideoPlayer";

export default async function Page() {
  const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/api/playlist`,{cache:"no-store"});
  const data = await res.json();
  return (
    <div style={{display:"flex"}}>
      <Sidebar playlists={data.playlists}/>
      <VideoPlayer/>
    </div>
  );
}