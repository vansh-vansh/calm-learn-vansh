export default function Sidebar({playlists}) {
  return (
    <div style={{width:"300px",borderRight:"1px solid #0ff"}}>
      <h2>Playlists</h2>
      {playlists.map(p=><div key={p.id}>{p.title}</div>)}
    </div>
  );
}