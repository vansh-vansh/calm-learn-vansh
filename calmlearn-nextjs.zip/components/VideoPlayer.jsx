export default function VideoPlayer(){
  return <div style={{flex:1,padding:"20px"}}>Select a playlist</div>;
}